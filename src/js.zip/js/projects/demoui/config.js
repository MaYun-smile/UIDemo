import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { actions, AppDispatcher, BillformStore } from 'yes';
import { Components } from 'yes-platform';   // eslint-disable-line
import {
    StackNavigator as stackNavigator,
    TabNavigator as tabNavigator,
    withNavigation,
    Header,
} from 'react-navigation';
import { generateTabRouter } from 'yes-router';
// import MTodoList from './page/mtodolist';
// import todolist from './page/todolist/todolist';
// import My from './page/my';
// import './template';
// import logoImage from './img/logo.png';
// import bgImage from './img/login_bg.jpg';
const { Login } = Components;
let rootEl = null;
try {
    if (document) {
        rootEl = document.getElementById('app');
    }
} catch (e) {
    console.info(e.message);    // eslint-disable-line no-console
}

const appOptions = {
    sessionKey: 'demoui',
    // serverPath:'http://1.1.8.221:8089/yigo',
    // serverPath: 'http://192.168.42.235:8089/yigo',
    serverPath: 'http://1.1.8.24:8089/yigo',
    appName: 'yesdemo',
    rootEl,
    loginConfig: {
        template: Login,
        tooltip: 'UI Demo',
        companyName: 'bokesoft',
        // bgImage,
        // logoImage,
    },

};
const MainRouter = generateTabRouter([{
    title: '测试',
    formKey: 'ComponentMain',
}]);

appOptions.router = MainRouter;
appOptions.mock = true;
appOptions.debug = true;
export default appOptions;
