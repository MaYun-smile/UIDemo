'use strict';
import {App} from "yes-platform";
import config from "./config";
export default new App(config);
