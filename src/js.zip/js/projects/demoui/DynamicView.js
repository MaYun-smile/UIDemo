/*
 * @Author: gmf
 * @Date:   2016-11-25 14:04:34
 * @Last Modified by:   gmf
 * @Last Modified time: 2016-11-25 14:32:28
 */

'use strict';

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Components } from 'yes-platform';
import { ScrollView } from 'react-native';
const { DynamicBillForm } = Components;

export default class DynamicView extends Component {
    render() {
        return (
            <ScrollView
                contentContainerStyle={{
                    flex: 1,
                    display: 'flex',
                    flexDirection: 'column',
                }}
            >
                <DynamicBillForm
                    formKey={this.props.navigation.state.params.metaKey}
                    status="EDIT"
                    oid={this.props.navigation.state.params ? this.props.navigation.state.params.id : -1}
                    {...this.props}
                    style={{
                        flex: 1,
                    }}
                >
                </DynamicBillForm>
            </ScrollView>
        );
    }
}
