import React, { Component } from 'react';
import { Components } from 'yes-platform';
import { ScrollView } from 'react-native';
const { DynamicBillForm, BillForm, OperationBar } = Components;
export default class ComponentMain extends Component {
    static navigationOptions = (navigation) => ({
        title: '控件演示',
        tabBarLabel: '控件演示',
        headerRight: <BillForm formKey="ComponentMain"><OperationBar /></BillForm>,
        headerStyle: {
            // backgroundColor: '#2196f3',
        },
    })
    render() {
        return (
            <ScrollView>
                <DynamicBillForm
                    formKey="ComponentMain"
                    status="EDIT"
                    oid="-1"
                />
            </ScrollView>
        );
    }
}
